package com.example.helloworld;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	// This is like the main method of your activity.
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Get access to the add button
		Button addButton = (Button) findViewById(R.id.button1);

		// Adds code that tells the button what to do when clicked
		addButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// Get access to the edit texts to read user input
				EditText firstInput = (EditText) findViewById(R.id.editText1);
				EditText secondInput = (EditText) findViewById(R.id.editText2);

				// addNumbers() just adds up the two inputs.
				// Replace it with your own method to react to user input
				int result = addNumbers(firstInput, secondInput);

				// Get access to the text view and set it to the answer
				TextView answerText = (TextView) findViewById(R.id.textView1);
				answerText.setText("Answer: " + result);
			}
		});
	}

	// Adds numbers from EditText objects
	private int addNumbers(EditText firstInput, EditText secondInput) {
		try {
			// Get the input as a String
			String firstInputString = firstInput.getText().toString();
			String secondInputString = secondInput.getText().toString();

			// Turn them into ints and add 'em!
			int firstNumber = Integer.parseInt(firstInputString);
			int secondNumber = Integer.parseInt(secondInputString);
			return firstNumber + secondNumber;
		} catch (Exception e) {

		}
		// I was lazy and so I just make it return -1 if there are any problems
		// parsing the String input. Don't be lazy like me!
		return -1;
	}

}
